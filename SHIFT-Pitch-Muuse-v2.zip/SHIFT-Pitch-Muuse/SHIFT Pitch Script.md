# SHIFT Pitch Script

Muuse · natHacks 2026

## Run of show (5:00 slot)

The pitch is 11 slides: about 3:00 of talking plus the 1:16 video, which leaves about 0:40 of buffer for transitions and a slow start. Slides 12–25 are backup for Q&A only; don't present them.

| Slide | What's on it | Time | Clock at end |
| --- | --- | --- | --- |
| 1 | Title | 0:10 | 0:10 |
| 2 | 270,000+ workers retiring | 0:15 | 0:25 |
| 3 | The week falls apart | 0:25 | 0:50 |
| 4 | Product video | 1:16 | 2:06 |
| 5 | Rain forecast to new plan | 0:25 | 2:31 |
| 6 | Three users | 0:25 | 2:56 |
| 7 | Built in 64 hours | 0:12 | 3:08 |
| 8 | vs. hiring platforms | 0:18 | 3:26 |
| 9 | Pricing | 0:15 | 3:41 |
| 10 | How we'd use the funding | 0:25 | 4:06 |
| 11 | Vision and thank you | 0:12 | 4:18 |

- **Keys:** arrows or Space to advance, **F** fullscreen, **N** shows these notes on screen.
- **Video:** the ad is included as `shift-ad.mp4` in the same folder as the deck. It plays with sound when slide 4 opens and stops when you advance.
- **Running long?** Cut slide 7 to one sentence and skip the competitor names on slide 8.

## Opening and problem (slides 1–3, 0:50)

### 1 · Title (0:10)

**Say:** "Hi, we're Muuse, and this is SHIFT: crew scheduling that keeps up when the real world changes."

**Notes:** Let the Gantt animation play while you speak: one bar gets rained out and moves to a slot that works.

### 2 · Fewer workers are doing more work (0:15)

**Say:** "Construction is running out of people. Over 270,000 Canadian construction workers retire by 2034, about one in seven. Fewer people are doing more work."

**Notes:** BuildForce Canada, via Deloitte (2026). Canada also needs 410–520K more workers by 2030 (slide 22).

### 3 · One storm, two sick calls, and the week falls apart (0:25)

**Say:** "And their plans are fragile. Weather alone stretches projects by about a quarter. Here's a normal week: the plan goes out by group text, a storm kills two days, two people call in sick, someone gets booked on two sites, and nobody can quickly check who's certified. So the manager rebuilds the week from a whiteboard. That's why we built SHIFT."

**Notes:** The ~26% figure is from a survey of 242 construction experts (Dong et al., Buildings, 2025); it's expert perception, not measured records. Chart on slide 13 if asked.

## Product video (slide 4, 1:16)

**Say (before):** nothing; slide 3 ends on "That's why we built SHIFT," then advance.

**During:** stay quiet and let it play. Don't talk over the ad.

**Say (after, as you advance to slide 5):** "Here's what you just saw, step by step."

**Notes:** Test the sound on the venue's laptop before you go up. If the file won't play, the slide shows a play button and "SHIFT in action"; play the video from its own file and come back.

## Solution and product (slides 5–8, 1:20)

### 5 · From rain forecast to a new plan (0:25)

**Say:** "Here's what you just saw, step by step. SHIFT checks the forecast against each task and logs absences. Our solver offers three plans: cheapest, fastest, or fewest changes. The manager approves, each worker accepts, and it's published. A solver decides what's feasible, not a chatbot, and nothing changes until a person says yes."

**Notes:** Solver is Google OR-Tools CP-SAT; it checks qualifications, rest periods, daily-hour limits, dependencies and weather thresholds. Principle slide is 14 if a judge pushes on AI trust.

### 6 · Contract work, made easy. For three people at once. (0:25)

**Say:** "SHIFT is one app for three people. Ilya, a labourer, only sees work he's qualified and free for. Rahul, hiring at Prairie Harvest Foods, gets ranked, verified applicants. Jordan bids whole framing crews with credentials on file. And saying yes books it: dates blocked, Google Calendar updated."

**Notes:** Two connected marketplaces: businesses hiring workers, and businesses hiring contracting companies. Every worker and company has a certification wallet with issuer, expiry and verification status.

### 7 · Built in 64 hours (0:12)

**Say:** "And it's real. We built all eight of these in 64 hours, and it runs end to end."

**Notes:** Stack: Next.js, FastAPI, SQLAlchemy, CP-SAT, Supabase sign-in with verified JWTs and PostgreSQL row-level security, Playwright end-to-end tests.

### 8 · They find workers. SHIFT keeps them working. (0:18)

**Say:** "Job sites like Indeed or TaskRabbit help you find a worker and stop there. SHIFT is the only one that keeps whole crews scheduled for weeks, re-plans for weather and absences, and gets approval first."

**Notes:** They charge per task, post or recruiter seat; SHIFT is a per-worker subscription. Double-check any competitor detail you expect to be challenged on.

## Business, ask and close (slides 9–11, 0:52)

### 9 · Workers use it free. Companies pay per worker. (0:15)

**Say:** "Workers and small crews use SHIFT free. Growing contractors pay twelve dollars per scheduled worker a month. For scale: one rained-out day for a 12-person crew wastes about $4,300, nearly six months of Pro for 60 workers."

**Notes:** CAD. Enterprise from $8/worker at 250+. Rainy-day math: 12 × 8 h × $45/h ≈ $4,320; 60 × $12 = $720/month (chart on slide 17).

### 10 · How we'd use $2,000 + $2,000 in-kind (0:25)

**Say:** "We're asking for first place: $2,000 seed and $2,000 in-kind. Priority one is users: getting workers on SHIFT, on actual job sites. Two, local businesses: pilots with Edmonton contractors and plants. Three, shipping everywhere crews are: web, iOS and Android, on Supabase and Vercel. The in-kind covers cloud credits, legal help and mentor intros."

**Notes:** Proposed split $800 / $600 / $600. List prices (check before presenting): Supabase Pro US$25/mo, Vercel Pro US$20/mo, Apple Developer US$99/yr, Google Play US$25 one-time. What more funding unlocks is slide 19.

### 11 · Every crew, on every project, always in sync (0:12)

**Say:** "Every crew, on every project, always in sync. When the weather turns, SHIFT turns with it. Tell us what would stop a crew from using this, and come try the demo. We're Muuse. Thank you."

**Notes:** Stay on this slide for Q&A.

## Q&A backup (slides 12–25)

Jump by typing `#` and the slide number at the end of the deck's address (for example `#22`), then press Enter.

| If a judge asks… | Jump to | Short answer |
| --- | --- | --- |
| "Where does the 26% come from?" | 13 · Weather impact | Survey of 242 construction experts: ~26% longer, ~24% costlier. Expert perception, not measured records. |
| "Why trust AI with schedules?" | 14 · Our principle | It isn't a language model. A constraint solver checks feasibility, and nothing changes until a manager approves and each worker accepts. |
| "Does optimization actually pay?" | 15 · Proof | UPS expected $300–400M/yr; Southwest lost $1.1B+ after a storm; the NHS and Minnesota DOT funded scheduling. Not our customers; proof of the method. |
| "What does it cost you to run?" | 16 · What it costs | $0 to build; ~$50/month for a first pilot (our estimate); the real cost is our time. |
| "Why would a contractor pay?" | 17 · Rained-out day | One idle day for 12 people ≈ $4,300, vs. $720/month of Pro for 60 workers. |
| "Who's the customer as you grow?" | 18 · Freelancer to PCL | Freelancers and small crews free, growing contractors on Pro, PCL-sized firms on Enterprise. |
| "What would more money unlock?" | 19 · More funding | Trust (training-provider verification, a verification team, a security audit), product (timesheets and payments, a morning digest, live weather), growth (provinces, industries, languages). |
| "Walk me through a day without SHIFT." | 20 · A normal Monday | Plan by text, rain plus a sick call, hours on the phone, crews collide, the deadline slips. |
| "Only construction?" | 21 · Two sectors | Same engine for private (crews, production lines) and public (snow crews, home care, emergency staffing). |
| "How big is the market?" | 22 · The market | US$1.31B (2024) to US$2.09B (2029), 9.8% a year; Canada needs 410–520K more workers by 2030. |
| "Don't project suites already do this?" | 23 · Today's tools | They own documents and budgets; crew re-planning is still manual. SHIFT can sit alongside them. |
| "What happens after natHacks?" | 24 · Go-to-market | Fall: talk to 10+ tradespeople. Winter 2027: one real pilot crew. Summer 2027: a case study and more Edmonton contractors. |
| "Where's that number from?" | 25 · Sources | Every figure with its source; pilot cost, pricing and the rainy-day math are our own estimates. |
