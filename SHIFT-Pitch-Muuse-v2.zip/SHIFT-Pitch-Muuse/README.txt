SHIFT pitch - Muuse, natHacks 2026

1. Open shift-pitch-deck.html in Chrome, Edge or Safari (double-click it).
2. The product ad (shift-ad.mp4, 1:16) is in this folder; keep it next to the deck.
   It plays with sound on slide 4 and stops when you move on.
3. Keys: arrows/Space = next/previous, F = fullscreen, N = speaker notes.
4. Jump to a backup slide: add #22 (or any number) to the end of the address and press Enter.

The script is in "SHIFT Pitch Script.docx" (also .md). Slides 1-11 are the 5-minute pitch;
slides 12-25 are Q&A backup. Fonts load from Google Fonts, so connect to the internet once
before presenting, or the deck falls back to system fonts.
